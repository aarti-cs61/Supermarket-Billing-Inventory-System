@echo off
echo Starting Supermarket Billing and Inventory System...
mvn clean compile
mvn exec:java
pause

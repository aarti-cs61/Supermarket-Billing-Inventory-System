package com.supermarket.service;

import com.supermarket.db.DBConnection;
import com.supermarket.exception.OutOfStockException;
import com.supermarket.model.Electronics;
import com.supermarket.model.Grocery;
import com.supermarket.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductService {

    public List<Product> getAllProducts() throws SQLException {
        List<Product> products = new ArrayList<>();

        String sql = "SELECT product_id, name, category, price, stock, gst_rate " +
                     "FROM products WHERE active = TRUE ORDER BY product_id";

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                products.add(createProduct(
                        rs.getInt("product_id"),
                        rs.getString("name"),
                        rs.getString("category"),
                        rs.getDouble("price"),
                        rs.getInt("stock"),
                        rs.getDouble("gst_rate")
                ));
            }
        }
        return products;
    }

    public Product findProduct(int id) throws SQLException {
        String sql = "SELECT product_id, name, category, price, stock, gst_rate " +
                     "FROM products WHERE product_id = ? AND active = TRUE";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return createProduct(
                            rs.getInt("product_id"),
                            rs.getString("name"),
                            rs.getString("category"),
                            rs.getDouble("price"),
                            rs.getInt("stock"),
                            rs.getDouble("gst_rate")
                    );
                }
            }
        }
        return null;
    }

    public void reduceStock(int productId, int quantity) throws SQLException, OutOfStockException {
        String checkSql = "SELECT stock FROM products WHERE product_id = ? FOR UPDATE";
        String updateSql = "UPDATE products SET stock = stock - ? WHERE product_id = ?";

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            try {
                int currentStock;

                try (PreparedStatement check = con.prepareStatement(checkSql)) {
                    check.setInt(1, productId);
                    try (ResultSet rs = check.executeQuery()) {
                        if (!rs.next()) {
                            throw new SQLException("Product not found.");
                        }
                        currentStock = rs.getInt("stock");
                    }
                }

                if (quantity > currentStock) {
                    throw new OutOfStockException(
                            "Only " + currentStock + " item(s) are available."
                    );
                }

                try (PreparedStatement update = con.prepareStatement(updateSql)) {
                    update.setInt(1, quantity);
                    update.setInt(2, productId);
                    update.executeUpdate();
                }

                con.commit();
            } catch (Exception e) {
                con.rollback();
                if (e instanceof OutOfStockException) {
                    throw (OutOfStockException) e;
                }
                if (e instanceof SQLException) {
                    throw (SQLException) e;
                }
                throw new SQLException(e);
            } finally {
                con.setAutoCommit(true);
            }
        }
    }

    public List<Product> getLowStockProducts(int limit) throws SQLException {
        List<Product> products = new ArrayList<>();

        String sql = "SELECT product_id, name, category, price, stock, gst_rate " +
                     "FROM products WHERE active = TRUE AND stock <= ? ORDER BY stock";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, limit);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    products.add(createProduct(
                            rs.getInt("product_id"),
                            rs.getString("name"),
                            rs.getString("category"),
                            rs.getDouble("price"),
                            rs.getInt("stock"),
                            rs.getDouble("gst_rate")
                    ));
                }
            }
        }
        return products;
    }

    private Product createProduct(int id, String name, String category,
                                  double price, int stock, double gstRate) {
        if ("Electronics".equalsIgnoreCase(category)) {
            return new Electronics(id, name, price, stock, gstRate);
        }
        return new Grocery(id, name, price, stock, gstRate);
    }
}

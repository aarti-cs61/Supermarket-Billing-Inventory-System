package com.supermarket.service;

import com.supermarket.db.DBConnection;
import com.supermarket.exception.OutOfStockException;
import com.supermarket.model.Bill;
import com.supermarket.model.CartItem;

import java.sql.*;

public class BillingService {
    private final ProductService productService = new ProductService();

    public int saveBill(Bill bill) throws SQLException, OutOfStockException {
        String billSql = "INSERT INTO bills(customer_name, subtotal, discount, gst, grand_total) " +
                         "VALUES (?, ?, ?, ?, ?)";
        String itemSql = "INSERT INTO bill_items(bill_id, product_id, quantity, unit_price, line_total) " +
                         "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            try {
                // Check stock first.
                for (CartItem item : bill.getItems()) {
                    String stockSql = "SELECT stock FROM products WHERE product_id = ? FOR UPDATE";
                    try (PreparedStatement ps = con.prepareStatement(stockSql)) {
                        ps.setInt(1, item.getProduct().getId());
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) {
                                throw new SQLException("Product does not exist.");
                            }
                            if (item.getQuantity() > rs.getInt("stock")) {
                                throw new OutOfStockException(
                                        item.getProduct().getName() + " has insufficient stock."
                                );
                            }
                        }
                    }
                }

                int billId;

                try (PreparedStatement ps = con.prepareStatement(
                        billSql, Statement.RETURN_GENERATED_KEYS)) {

                    ps.setString(1, bill.getCustomerName());
                    ps.setDouble(2, bill.getSubtotal());
                    ps.setDouble(3, bill.getDiscount());
                    ps.setDouble(4, bill.getGST());
                    ps.setDouble(5, bill.getGrandTotal());
                    ps.executeUpdate();

                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException("Could not create bill.");
                        }
                        billId = keys.getInt(1);
                    }
                }

                try (PreparedStatement itemPs = con.prepareStatement(itemSql);
                     PreparedStatement stockPs = con.prepareStatement(
                             "UPDATE products SET stock = stock - ? WHERE product_id = ?")) {

                    for (CartItem item : bill.getItems()) {
                        itemPs.setInt(1, billId);
                        itemPs.setInt(2, item.getProduct().getId());
                        itemPs.setInt(3, item.getQuantity());
                        itemPs.setDouble(4, item.getProduct().getPrice());
                        itemPs.setDouble(5, item.getTotal());
                        itemPs.addBatch();

                        stockPs.setInt(1, item.getQuantity());
                        stockPs.setInt(2, item.getProduct().getId());
                        stockPs.addBatch();
                    }

                    itemPs.executeBatch();
                    stockPs.executeBatch();
                }

                con.commit();
                return billId;

            } catch (Exception e) {
                con.rollback();

                if (e instanceof OutOfStockException) {
                    throw (OutOfStockException) e;
                }
                if (e instanceof SQLException) {
                    throw (SQLException) e;
                }
                throw new SQLException(e);

            } finally {
                con.setAutoCommit(true);
            }
        }
    }

    public double getBillTotalUsingCallableStatement(int billId) throws SQLException {
        String sql = "{call get_bill_total(?, ?)}";

        try (Connection con = DBConnection.getConnection();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, billId);
            cs.registerOutParameter(2, Types.DECIMAL);
            cs.execute();

            return cs.getDouble(2);
        }
    }
}

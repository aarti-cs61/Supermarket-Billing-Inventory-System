package com.supermarket.service;

import com.supermarket.model.Product;

import java.util.List;

public class StockMonitor extends Thread {
    private final ProductService productService;
    private volatile boolean running = true;

    public StockMonitor(ProductService productService) {
        this.productService = productService;
        setName("Stock-Monitor");
        setDaemon(true);
    }

    @Override
    public void run() {
        while (running) {
            try {
                List<Product> lowStock = productService.getLowStockProducts(5);

                if (!lowStock.isEmpty()) {
                    System.out.println("[Stock Monitor] Low-stock items: " + lowStock.size());
                }

                Thread.sleep(30000);
            } catch (Exception e) {
                System.out.println("[Stock Monitor] " + e.getMessage());
            }
        }
    }

    public void stopMonitor() {
        running = false;
        interrupt();
    }
}

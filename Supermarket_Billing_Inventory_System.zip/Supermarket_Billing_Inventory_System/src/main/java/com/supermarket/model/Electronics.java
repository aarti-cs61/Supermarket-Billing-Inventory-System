package com.supermarket.model;

public class Electronics extends Product {
    public Electronics(int id, String name, double price, int stock, double gstRate) {
        super(id, name, price, stock, gstRate);
    }

    @Override
    public double calculatePrice(int quantity) {
        // A small service charge is applied to electronics.
        double serviceCharge = getPrice() * quantity * 0.02;
        return getPrice() * quantity + serviceCharge;
    }
}

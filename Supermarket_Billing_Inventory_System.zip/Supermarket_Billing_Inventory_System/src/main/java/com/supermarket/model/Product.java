package com.supermarket.model;

public abstract class Product implements Taxable {
    private int id;
    private String name;
    private double price;
    private int stock;
    private double gstRate;

    public Product(int id, String name, double price, int stock, double gstRate) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.gstRate = gstRate;
    }

    public abstract double calculatePrice(int quantity);

    @Override
    public double calculateGST(double amount) {
        return amount * gstRate / 100.0;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getStock() { return stock; }
    public double getGstRate() { return gstRate; }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getCategory() {
        return getClass().getSimpleName();
    }

    @Override
    public String toString() {
        return id + " - " + name + " (" + getCategory() + ")";
    }
}

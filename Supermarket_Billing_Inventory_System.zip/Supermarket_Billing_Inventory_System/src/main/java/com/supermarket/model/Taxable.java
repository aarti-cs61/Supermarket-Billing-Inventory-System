package com.supermarket.model;

public interface Taxable {
    double calculateGST(double amount);
}

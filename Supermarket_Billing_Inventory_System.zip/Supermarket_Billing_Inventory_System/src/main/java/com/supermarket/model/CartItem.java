package com.supermarket.model;

public class CartItem {
    private final Product product;
    private final int quantity;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getBaseAmount() {
        return product.getPrice() * quantity;
    }

    public double getGST() {
        return product.calculateGST(getBaseAmount());
    }

    public double getTotal() {
        return product.calculatePrice(quantity);
    }
}

package com.supermarket.model;

public class Grocery extends Product {
    public Grocery(int id, String name, double price, int stock, double gstRate) {
        super(id, name, price, stock, gstRate);
    }

    @Override
    public double calculatePrice(int quantity) {
        // Grocery items use the normal unit price.
        return getPrice() * quantity;
    }
}

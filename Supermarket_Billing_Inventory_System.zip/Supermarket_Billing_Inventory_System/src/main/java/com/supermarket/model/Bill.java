package com.supermarket.model;

import java.util.ArrayList;
import java.util.List;

public class Bill {
    private final String customerName;
    private final List<CartItem> items = new ArrayList<>();

    public Bill(String customerName) {
        this.customerName = customerName;
    }

    public void addItem(CartItem item) {
        items.add(item);
    }

    public String getCustomerName() {
        return customerName;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public double getSubtotal() {
        double total = 0;
        for (CartItem item : items) {
            total += item.getTotal();
        }
        return total;
    }

    public double getDiscount() {
        // Simple student-project billing rule.
        if (getSubtotal() >= 2000) return getSubtotal() * 0.10;
        if (getSubtotal() >= 1000) return getSubtotal() * 0.05;
        return 0;
    }

    public double getGST() {
        double gst = 0;
        for (CartItem item : items) {
            gst += item.getGST();
        }
        return gst;
    }

    public double getGrandTotal() {
        return getSubtotal() - getDiscount() + getGST();
    }
}

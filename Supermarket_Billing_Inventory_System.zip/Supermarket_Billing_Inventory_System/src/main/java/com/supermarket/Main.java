package com.supermarket;

import com.supermarket.service.ProductService;
import com.supermarket.service.StockMonitor;
import com.supermarket.ui.MainFrame;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        ProductService productService = new ProductService();

        // This background thread checks stock periodically.
        StockMonitor monitor = new StockMonitor(productService);
        monitor.start();

        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}

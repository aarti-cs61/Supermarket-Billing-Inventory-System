package com.supermarket.ui;

import com.supermarket.exception.OutOfStockException;
import com.supermarket.model.Bill;
import com.supermarket.model.CartItem;
import com.supermarket.model.Product;
import com.supermarket.service.BillingService;
import com.supermarket.service.ProductService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainFrame extends JFrame {
    private final ProductService productService = new ProductService();
    private final BillingService billingService = new BillingService();
    private final DecimalFormat money = new DecimalFormat("0.00");

    private final JComboBox<Product> productBox = new JComboBox<>();
    private final JSpinner quantitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
    private final JTextField customerField = new JTextField("Walk-in Customer");
    private final DefaultListModel<String> cartModel = new DefaultListModel<>();
    private final JList<String> cartList = new JList<>(cartModel);

    private final JLabel subtotalLabel = new JLabel("₹0.00");
    private final JLabel discountLabel = new JLabel("₹0.00");
    private final JLabel gstLabel = new JLabel("₹0.00");
    private final JLabel totalLabel = new JLabel("₹0.00");

    private final List<CartItem> cart = new ArrayList<>();

    public MainFrame() {
        setTitle("Supermarket Billing & Inventory System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 650);
        setLocationRelativeTo(null);

        buildUI();
        loadProducts();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));
        setContentPane(root);

        root.add(createHeader(), BorderLayout.NORTH);
        root.add(createProductPanel(), BorderLayout.WEST);
        root.add(createCartPanel(), BorderLayout.CENTER);
        root.add(createBillPanel(), BorderLayout.EAST);
    }

    private JPanel createHeader() {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel title = new JLabel("SUPER MARKET BILLING");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));

        JLabel sub = new JLabel("Simple POS • Stock • GST • Billing");
        sub.setForeground(Color.DARK_GRAY);

        JPanel text = new JPanel();
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.add(title);
        text.add(sub);

        panel.add(text, BorderLayout.WEST);
        return panel;
    }

    private JPanel createProductPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 8, 8));
        panel.setPreferredSize(new Dimension(260, 0));
        panel.setBorder(BorderFactory.createTitledBorder("Products"));

        productBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if (value instanceof Product p) {
                    setText(p.getName() + " | ₹" + money.format(p.getPrice())
                            + " | Stock: " + p.getStock());
                }
                return this;
            }
        });

        JButton addButton = new JButton("Add to Cart");
        addButton.addActionListener(e -> addToCart());

        JButton refreshButton = new JButton("Refresh Products");
        refreshButton.addActionListener(e -> loadProducts());

        JButton lowStockButton = new JButton("Low Stock Report");
        lowStockButton.addActionListener(e -> showLowStockReport());

        panel.add(new JLabel("Select product:"));
        panel.add(productBox);
        panel.add(new JLabel("Quantity:"));
        panel.add(quantitySpinner);
        panel.add(addButton);
        panel.add(refreshButton);
        panel.add(lowStockButton);

        return panel;
    }

    private JPanel createCartPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("Current Cart"));

        cartList.setFont(new Font("Monospaced", Font.PLAIN, 13));
        panel.add(new JScrollPane(cartList), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton removeButton = new JButton("Remove Selected");
        removeButton.addActionListener(e -> removeSelectedItem());

        JButton clearButton = new JButton("Clear Cart");
        clearButton.addActionListener(e -> clearCart());

        bottom.add(removeButton);
        bottom.add(clearButton);
        panel.add(bottom, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createBillPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setPreferredSize(new Dimension(260, 0));
        panel.setBorder(BorderFactory.createTitledBorder("Billing"));

        JPanel top = new JPanel(new GridLayout(2, 1, 4, 4));
        top.add(new JLabel("Customer name:"));
        top.add(customerField);
        panel.add(top, BorderLayout.NORTH);

        JPanel totals = new JPanel(new GridLayout(0, 2, 5, 10));
        totals.add(new JLabel("Subtotal:"));
        totals.add(subtotalLabel);
        totals.add(new JLabel("Discount:"));
        totals.add(discountLabel);
        totals.add(new JLabel("GST:"));
        totals.add(gstLabel);

        JLabel grand = new JLabel("Grand Total:");
        grand.setFont(new Font("SansSerif", Font.BOLD, 15));
        totalLabel.setFont(new Font("SansSerif", Font.BOLD, 15));

        totals.add(grand);
        totals.add(totalLabel);

        panel.add(totals, BorderLayout.CENTER);

        JButton generate = new JButton("Generate Bill");
        generate.setFont(new Font("SansSerif", Font.BOLD, 14));
        generate.addActionListener(e -> generateBill());

        panel.add(generate, BorderLayout.SOUTH);

        return panel;
    }

    private void loadProducts() {
        try {
            List<Product> products = productService.getAllProducts();
            productBox.removeAllItems();

            for (Product product : products) {
                productBox.addItem(product);
            }

            if (products.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No products found.");
            }

        } catch (SQLException ex) {
            showError("Could not load products. Check MySQL connection.", ex);
        }
    }

    private void addToCart() {
        Product product = (Product) productBox.getSelectedItem();
        int quantity = (Integer) quantitySpinner.getValue();

        if (product == null) {
            JOptionPane.showMessageDialog(this, "Please select a product.");
            return;
        }

        if (quantity > product.getStock()) {
            JOptionPane.showMessageDialog(this,
                    "Only " + product.getStock() + " item(s) are available.");
            return;
        }

        cart.add(new CartItem(product, quantity));
        refreshCart();
    }

    private void removeSelectedItem() {
        int index = cartList.getSelectedIndex();

        if (index >= 0) {
            cart.remove(index);
            refreshCart();
        }
    }

    private void clearCart() {
        cart.clear();
        refreshCart();
    }

    private void refreshCart() {
        cartModel.clear();

        Bill tempBill = new Bill(customerField.getText().trim().isEmpty()
                ? "Walk-in Customer" : customerField.getText().trim());

        for (CartItem item : cart) {
            tempBill.addItem(item);

            String line = String.format(
                    "%-18s x%-3d ₹%8s",
                    item.getProduct().getName(),
                    item.getQuantity(),
                    money.format(item.getTotal())
            );
            cartModel.addElement(line);
        }

        subtotalLabel.setText("₹" + money.format(tempBill.getSubtotal()));
        discountLabel.setText("₹" + money.format(tempBill.getDiscount()));
        gstLabel.setText("₹" + money.format(tempBill.getGST()));
        totalLabel.setText("₹" + money.format(tempBill.getGrandTotal()));
    }

    private void generateBill() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Cart is empty.");
            return;
        }

        String customer = customerField.getText().trim();
        if (customer.isEmpty()) {
            customer = "Walk-in Customer";
        }

        Bill bill = new Bill(customer);
        for (CartItem item : cart) {
            bill.addItem(item);
        }

        try {
            int billId = billingService.saveBill(bill);
            double totalFromDatabase =
                    billingService.getBillTotalUsingCallableStatement(billId);

            String receipt = buildReceipt(billId, bill, totalFromDatabase);

            JTextArea area = new JTextArea(receipt);
            area.setFont(new Font("Monospaced", Font.PLAIN, 13));
            area.setEditable(false);

            JOptionPane.showMessageDialog(
                    this,
                    new JScrollPane(area),
                    "Bill Generated",
                    JOptionPane.INFORMATION_MESSAGE
            );

            cart.clear();
            refreshCart();
            loadProducts();

        } catch (OutOfStockException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Stock Problem", JOptionPane.WARNING_MESSAGE);
            loadProducts();

        } catch (SQLException ex) {
            showError("Bill could not be saved.", ex);
        }
    }

    private String buildReceipt(int billId, Bill bill, double totalFromDatabase) {
        StringBuilder sb = new StringBuilder();

        sb.append("====================================\n");
        sb.append("       SUPER MARKET BILL\n");
        sb.append("====================================\n");
        sb.append("Bill No. : ").append(billId).append("\n");
        sb.append("Customer : ").append(bill.getCustomerName()).append("\n");
        sb.append("------------------------------------\n");

        for (CartItem item : bill.getItems()) {
            sb.append(String.format(
                    "%-18s x%-3d ₹%8s%n",
                    item.getProduct().getName(),
                    item.getQuantity(),
                    money.format(item.getTotal())
            ));
        }

        sb.append("------------------------------------\n");
        sb.append(String.format("Subtotal      : ₹%10s%n", money.format(bill.getSubtotal())));
        sb.append(String.format("Discount      : ₹%10s%n", money.format(bill.getDiscount())));
        sb.append(String.format("GST           : ₹%10s%n", money.format(bill.getGST())));
        sb.append(String.format("Grand Total   : ₹%10s%n", money.format(totalFromDatabase)));
        sb.append("====================================\n");
        sb.append("       Thank you for shopping!\n");

        return sb.toString();
    }

    private void showLowStockReport() {
        try {
            List<Product> lowStock = productService.getLowStockProducts(5);

            if (lowStock.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "No products are currently low in stock.");
                return;
            }

            StringBuilder report = new StringBuilder();
            report.append("LOW STOCK REPORT\n\n");

            for (Product p : lowStock) {
                report.append(String.format(
                        "%-22s Stock: %d%n",
                        p.getName(),
                        p.getStock()
                ));
            }

            JOptionPane.showMessageDialog(this, report.toString(),
                    "Low Stock", JOptionPane.WARNING_MESSAGE);

        } catch (SQLException ex) {
            showError("Could not generate low-stock report.", ex);
        }
    }

    private void showError(String message, Exception ex) {
        JOptionPane.showMessageDialog(
                this,
                message + "\n\n" + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

CREATE DATABASE IF NOT EXISTS supermarket_db;
USE supermarket_db;

DROP PROCEDURE IF EXISTS get_bill_total;

DROP TABLE IF EXISTS bill_items;
DROP TABLE IF EXISTS bills;
DROP TABLE IF EXISTS products;

CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(80) NOT NULL,
    category VARCHAR(30) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    gst_rate DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE bills (
    bill_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(80) NOT NULL,
    bill_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    subtotal DECIMAL(10,2) NOT NULL,
    discount DECIMAL(10,2) NOT NULL,
    gst DECIMAL(10,2) NOT NULL,
    grand_total DECIMAL(10,2) NOT NULL
);

CREATE TABLE bill_items (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    bill_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    line_total DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_bill_items_bill
        FOREIGN KEY (bill_id) REFERENCES bills(bill_id),
    CONSTRAINT fk_bill_items_product
        FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO products(name, category, price, stock, gst_rate) VALUES
('Milk 1L', 'Grocery', 58.00, 25, 5.00),
('Bread', 'Grocery', 45.00, 18, 5.00),
('Rice 5kg', 'Grocery', 320.00, 12, 5.00),
('Biscuits', 'Grocery', 30.00, 40, 5.00),
('USB Keyboard', 'Electronics', 650.00, 8, 18.00),
('Wireless Mouse', 'Electronics', 850.00, 6, 18.00),
('Earphones', 'Electronics', 499.00, 10, 18.00);

DELIMITER $$

CREATE PROCEDURE get_bill_total(IN p_bill_id INT, OUT p_total DECIMAL(10,2))
BEGIN
    SELECT grand_total INTO p_total
    FROM bills
    WHERE bill_id = p_bill_id;
END$$

DELIMITER ;

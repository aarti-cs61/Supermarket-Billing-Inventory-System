# Supermarket Billing and Inventory System

**Java Mini Project - CSE2003 Object Oriented Programming using JAVA**

A small point-of-sale application made with Java Swing and JDBC. It keeps product
stock, adds products to a shopping cart, calculates discount and GST, saves bills,
and gives a low-stock report.

## Team

- Vamil Singla - 2510001293 (Leader)
- Aarti - 2510001262
- Jaismeenpreet Kaur - 2510001239
- Nikita - 2510001231

## Modules

1. Product master
2. Billing counter with cart
3. Discount and GST calculation
4. Stock update after sale
5. Low-stock report

## Java concepts used

- Classes and objects
- Encapsulation
- Inheritance (`Product` -> `Grocery`, `Electronics`)
- Abstract class and abstract method
- Interface (`Taxable`)
- Custom exception (`OutOfStockException`)
- Thread for stock monitoring
- JDBC `Statement`, `PreparedStatement`, and `CallableStatement`
- Swing `GridLayout`, `BorderLayout`, buttons and action events
- String and Character handling

## Database

MySQL database name: `supermarket_db`

Tables:
- `products`
- `bills`
- `bill_items`

A stored procedure named `get_bill_total` is also created for demonstrating
`CallableStatement`.

## How to run

1. Install JDK 17 and MySQL.
2. Run `src/main/resources/schema.sql` in MySQL.
3. Open `src/main/java/com/supermarket/db/DBConnection.java` and change the
   MySQL username/password if needed.
4. From the project folder run:

```bash
mvn clean compile
mvn exec:java
```

The application opens a Swing billing window.

## Default database settings

- URL: `jdbc:mysql://localhost:3306/supermarket_db`
- User: `root`
- Password: `root`

Change the password in `DBConnection.java` if your MySQL setup is different.
